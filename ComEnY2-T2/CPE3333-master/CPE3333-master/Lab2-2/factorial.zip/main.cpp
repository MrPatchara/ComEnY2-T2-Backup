using namespace std;
#include <iostream>
#include "functions.h"

int main(){
	print_hello();
	cout << endl;
	cout << "The factorial of 6 is " << factorial(6) << endl;
	return 0;
}
