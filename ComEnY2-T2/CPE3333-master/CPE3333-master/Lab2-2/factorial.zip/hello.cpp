using namespace std;
#include <iostream>
#include "functions.h"

void print_hello(){
	cout << "Hello You";
}
